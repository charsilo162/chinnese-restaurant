php create_migration.php create_sample_tables to create migration files

